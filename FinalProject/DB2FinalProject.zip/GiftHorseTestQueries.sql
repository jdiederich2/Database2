-- Specify the database to use.
-- If you don't have boardgames yet, right click in your schemas pane to the
--   left and create a new schema.
USE boardgames;

-- Display a Product Catalog
SELECT * FROM gifthorse.product;


-- Produce a list of items that make up each product
SELECT basketcontents.ProdID, ProdName, items.ItemID, ItemDesc, UnitOfMeasure, ItemQty
FROM basketcontents, items, product
WHERE basketcontents.ItemID = items.ItemID
AND basketcontents.ProdID = product.ProdID
ORDER BY ProdID, ItemID;


SELECT c.CustFName, c.CustLName, c.CustAddr, c.CustCity, c.CustState, c.CustZip
FROM customer AS c
WHERE CustID
	IN (select CustID FROM orders where OrdID = 100422);
    
SELECT c.CustFName, c.CustLName, c.CustAddr, c.CustCity, c.CustState, c.CustZip
FROM customer AS c, orders
WHERE c.CustID = OrdID
AND ShipToCustID = OrdID
	IN (select ShipToCustID FROM orders where OrdID = 100422);

-- Track the items that make up products and company that supply them
SELECT items.ItemID, VendCompany, VendCity, ItemPrice
FROM items
LEFT JOIN vendor ON items.VendID = vendor.VendID
ORDER BY VendCity, VendCompany, ItemID;

