CREATE DATABASE  IF NOT EXISTS `farmco` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `farmco`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: farmco
-- ------------------------------------------------------
-- Server version	5.7.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `building`
--

DROP TABLE IF EXISTS `building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `building` (
  `buildID` char(4) NOT NULL,
  `buildName` varchar(30) NOT NULL,
  `buildType` char(1) NOT NULL,
  `buildMgr` char(4) NOT NULL,
  PRIMARY KEY (`buildID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `building`
--

LOCK TABLES `building` WRITE;
/*!40000 ALTER TABLE `building` DISABLE KEYS */;
INSERT INTO `building` VALUES ('dair','Dairy Building','d','1000'),('main','Main Office','o','0340'),('nbrn','North Cattle Barn','b','1000'),('pbr2','Pig Barn Annex','b','4000'),('pbrn','Main Pig Barn','b','4000'),('sbrn','South Cattle Barn','b','1000'),('whs1','Warehouse 1 - Feed and Medical','s','4500'),('whs2','Warehouse 2 - Bedding and Equi','s','4500');
/*!40000 ALTER TABLE `building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `empID` char(4) NOT NULL,
  `empLname` char(15) NOT NULL,
  `empFname` char(15) NOT NULL,
  `salary` decimal(10,2) NOT NULL,
  `hireDate` date NOT NULL,
  `address` varchar(35) NOT NULL,
  `city` char(20) NOT NULL,
  `state` char(2) NOT NULL DEFAULT 'WI',
  `zip` char(10) NOT NULL DEFAULT '54729',
  PRIMARY KEY (`empID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES ('0200','Vega','Jan',22000.00,'2004-02-04','1010 Grant Avenue','Kater','WI','54729'),('0211','Vega','Augie',46000.00,'2004-02-02','1010 Grant Avenue','Kater','WI','54729'),('0222','Vartanian','Mary Beth',36000.00,'2009-03-05','29 Eastbay Street Apt 12','Pansy','WI','54729'),('0230','Green','Tabitha',45900.00,'2006-02-14','123 Stoddard Road','Kater','WI','54729'),('0255','Hobart-Evensong','Michael',49000.00,'2009-12-05','4678 E Wagontrail Road','Blenker','WI','54729'),('0300','Dziengel','Calvin',12000.00,'2012-01-09','123 Watertower Lane','Pansy','WI','54729'),('0340','Griffinhoffer','Bella',72000.00,'2009-05-28','3899 Birdsong Drive','Kater','WI','54729'),('0400','Grenseth','Valerie',39000.00,'2010-11-14','56 1/2 Main Street','Blenker','WI','54729'),('0411','Mang','Michael',39800.00,'2011-01-12','690 8th Avenue','Blenker','WI','54729'),('0455','Bergen','Willa',12000.00,'2011-12-12','FN43567','Kater','WI','54729'),('1000','YourLNm','YourFNm',62000.00,'2012-12-01','610 W Green','Tofer','WI','54701'),('4000','Raminski','Darwin',78000.00,'2004-02-01','379 Bluebird Court','Pansy','WI','54729'),('4500','Destry','Curtis',78000.00,'2004-02-01','4500 Penny Lane','Kater','WI','54729');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `position`
--

DROP TABLE IF EXISTS `position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `position` (
  `posCode` char(2) NOT NULL,
  `posDesc` varchar(60) NOT NULL,
  PRIMARY KEY (`posCode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `position`
--

LOCK TABLES `position` WRITE;
/*!40000 ALTER TABLE `position` DISABLE KEYS */;
INSERT INTO `position` VALUES ('01','Building Manager'),('02','Office Manager'),('03','Dairy Worker - Milker'),('04','Dairy Worker - Processing'),('05','Bookkeeping'),('06','Custodial and Maintenance'),('07','Shift Supervisor'),('08','Intern/Trainee'),('09','Administrative Assistant'),('10','Human Resources Technician'),('11','Dairy Worker - Assistant'),('12','Receptionist');
/*!40000 ALTER TABLE `position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staffing`
--

DROP TABLE IF EXISTS `staffing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staffing` (
  `empID` char(4) NOT NULL,
  `buildID` char(4) NOT NULL,
  `posCode` char(2) NOT NULL,
  `shift` int(11) NOT NULL,
  PRIMARY KEY (`empID`,`buildID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staffing`
--

LOCK TABLES `staffing` WRITE;
/*!40000 ALTER TABLE `staffing` DISABLE KEYS */;
INSERT INTO `staffing` VALUES ('0200','whs1','06',1),('0200','whs2','06',1),('0211','main','02',0),('0222','dair','04',2),('0230','nbrn','07',2),('0230','sbrn','07',2),('0255','sbrn','07',3),('0300','whs2','08',1),('0340','main','01',0),('0400','main','05',1),('0411','nbrn','03',3),('0455','dair','08',1),('1000','dair','01',0),('1000','nbrn','01',0),('1000','sbrn','01',0),('4000','pbr2','01',0),('4000','pbrn','01',0),('4500','whs1','01',0),('4500','whs2','01',0);
/*!40000 ALTER TABLE `staffing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock` (
  `stockNum` int(11) NOT NULL,
  `stockType` char(3) NOT NULL,
  `breed` char(20) NOT NULL,
  `gender` char(1) NOT NULL,
  `stockName` varchar(50) NOT NULL,
  `birthdate` date NOT NULL,
  `buildID` char(4) NOT NULL,
  PRIMARY KEY (`stockNum`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock`
--

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
INSERT INTO `stock` VALUES (100,'hog','Welsh','f','Irene','2010-04-13','pbrn'),(101,'hog','American Saddleback','m','Buddy','2009-02-11','pbr2'),(102,'hog','Welsh','f','Isabelle','2010-04-13','pbrn'),(103,'hog','American Saddleback','m','Randy','2010-05-01','pbr2'),(104,'hog','Welsh','f','Irma','2010-04-13','pbrn'),(105,'hog','American Saddleback','f','Candy','2010-05-01','pbr2'),(106,'hog','Welsh','f','Imogene','2010-04-13','pbrn'),(108,'hog','Welsh','f','Arianna','2009-05-07','pbrn'),(109,'hog','American Saddleback','f','Andi','2010-05-01','pbr2'),(111,'hog','American Saddleback','m','Dobie','2009-06-01','pbr2'),(1200,'bov','Holstein','f','Flossie','2009-12-15','nbrn'),(1201,'bov','Holstein','f','Cindy','2008-02-21','sbrn'),(1202,'bov','Guernsey','f','Millie','2010-08-08','nbrn'),(1203,'bov','Holstein','f','Veronica','2007-12-21','sbrn'),(1204,'bov','Guernsey','f','Fifi','2010-08-16','nbrn'),(1205,'bov','Holstein','f','Sarafina','2010-06-01','sbrn'),(1206,'bov','Guernsey','f','Mona','2010-08-18','nbrn'),(1207,'bov','Guernsey','f','Margarita','2009-07-01','nbrn'),(1208,'bov','Holstein','b','Mighty Joe','2006-05-11','nbrn'),(1209,'bov','Guernsey','f','Delsey','2009-05-01','nbrn'),(1210,'bov','Holstein','b','Big Bad Bart','2007-05-13','nbrn'),(1211,'bov','Guernsey','f','Nancy Belle','2009-05-15','sbrn'),(1212,'bov','Holstein','f','Bodette','2009-05-13','sbrn'),(1213,'bov','Guernsey','f','Gretchen','2010-05-25','sbrn'),(1214,'bov','Holstein','f','Betty Lou','2009-05-23','sbrn');
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-17 21:54:59
