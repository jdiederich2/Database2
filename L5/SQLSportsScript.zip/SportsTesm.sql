/* Script to create the Sports Team database, generate and load two tables.
     By Jennifer Diederich on September 29, 2017. */

-- Drops the sportsteam table if it already exists
DROP DATABASE IF EXISTS sportsteam;

-- Creates the database sportsteam 
CREATE DATABASE sportsteam;

-- Specifies to use the sportsteam databse for the rest of the queries 
USE sportsteam;

-- Create Team table
CREATE TABLE team (
	teamNum char(4) PRIMARY KEY,
	teamName char(25) NOT NULL,
	teamMgr char(5)
);

-- Create Player table
CREATE TABLE player (
	playerID char(5) PRIMARY KEY,
	lname char(20) NOT NULL,
	fname char(20) NOT NULL,
	DOB DATE,
	teamNum char(4)
);

-- Populate Team table
INSERT INTO team VALUES
	('0100', 'Tigers', '00300'),
	('0200', 'Raging Bulls', '00440'),
	('0300', 'Brumies', '05550');
	
 -- Populate Player table   
INSERT INTO player VALUES
	('00100', 'Petrik', 'Jan', '2000-01-19', '0100'),
	('00110', 'Boggs', 'Darwin', '1999-12-14', '0100'),
	('00120', 'Deer', 'Edwin', '1000-11-01', '0100'),
	('00130', 'Howe', 'Ian', '2000-04-19', '0200'),
	('00140', 'Meeksma', 'Jorin', '1999-12-14', '0200'),
	('00150', 'Deer', 'Imara', '2000-01-03', '0200');

